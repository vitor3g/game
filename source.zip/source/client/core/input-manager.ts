export class InputManager {
  private keys: Record<string, boolean> = {};
  private mouse = {
    x: 0,
    y: 0,
    left: false,
    right: false,
  };

  constructor() {
    this.setupListeners();
  }

  private setupListeners(): void {
    window.addEventListener('keydown', (e) => {
      this.keys[e.code] = true;
    });

    window.addEventListener('keyup', (e) => {
      this.keys[e.code] = false;
    });

    window.addEventListener('mousemove', (e) => {
      this.mouse.x = e.clientX;
      this.mouse.y = e.clientY;
    });

    window.addEventListener('mousedown', (e) => {
      if (e.button === 0) this.mouse.left = true;
      if (e.button === 2) this.mouse.right = true;
    });

    window.addEventListener('mouseup', (e) => {
      if (e.button === 0) this.mouse.left = false;
      if (e.button === 2) this.mouse.right = false;
    });

    window.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  public isKeyDown(code: string): boolean {
    return !!this.keys[code];
  }

  public isMouseDown(button: 'left' | 'right'): boolean {
    return this.mouse[button];
  }

  public getMousePosition(): { x: number; y: number } {
    return { x: this.mouse.x, y: this.mouse.y };
  }
}
