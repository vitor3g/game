import * as CANNON from "cannon-es";
import CannonDebugger from 'cannon-es-debugger';
import * as THREE from "three";
import { ObjectEntity } from "../core/entities/object.entity";
import { RigidBody } from "../physics/rigid-body";

const ebisu_test = [
  "/data/ebisu/ebisuminami1.glb",
  //"/data/ebisu/ebisuminami2.glb",
  //"/data/ebisu/ebisuminami3.glb",
  //"/data/ebisu/ebisuminami4.glb",
  //"/data/ebisu/ebisuminami5.glb",
  //"/data/ebisu/ebisuminami6.glb",
  //"/data/ebisu/ebisuminami7.glb",
]


export class Game {
  private debuggerCannon!: any
  constructor() {}

  public async init() {


    this.debuggerCannon = CannonDebugger(g_core.getGraphics().getRenderer().scene, g_core.getPhysics().getWorld())


    ebisu_test.map(async (v, i) => {
      const object = await g_core.getObjects().createObject({
        modelInfo: {
          id: i,
          path: v
        },
      });

      const model = g_core.getModels().getModelById(object.getModelId());

      if (model) {
        g_core.getGraphics().getRenderer().scene.add(model.getMesh());
      }

      g_core.getEntityManager().add(object)
    })

    const boxShape = new CANNON.Box(new CANNON.Vec3(0.5, 0.5, 0.5));

    // Cria o mesh
    const boxGeometry = new THREE.BoxGeometry(1, 1, 1);
    const boxMaterial = new THREE.MeshStandardMaterial({ color: 0x00ff00 });
    const boxMesh = new THREE.Mesh(boxGeometry, boxMaterial);

    // Define a posição inicial do mesh
    boxMesh.position.set(0, 10, -7); // exemplo: x=0, y=5, z=0

    // Adiciona o mesh à cena
    g_core.getGraphics().getRenderer().scene.add(boxMesh);

    // Cria o corpo físico e define a posição inicial
    const rigidBody = new RigidBody(boxShape, 1); // 1 = massa
    rigidBody.getBody().position.set(0, 10, -7); // mesma posição do mesh

    const entity = new ObjectEntity({
      objectId: 777,
      modelId: 777,
      rigidBody,
      mesh: boxMesh,
    });

    // Se quiser que ele seja usado no sistema, ative essa linha:
    g_core.getEntityManager().add(entity);


    g_core
      .getTickManager()
      .subscribe("on-client-render", this.onClientRender.bind(this));


    return 1;
  }

  public onClientRender() {
    const io = g_core.getGraphics().getGUI().getIO();
    if (!io) return;

    const fps = io.Framerate.toFixed(1);

    const values = {
      fps: fps,
      modelsCount: g_core.getModels().getModelCount(),
      inMemoryObjects: g_core.getObjects().getObjectCount(),
    };



    this.debuggerCannon.update()
    g_core
      .getGraphics()
      .getGUI()
      .getPrimitiveList()
      .addText(JSON.stringify(values, null, 2), 10, 10, "#090909");
  }
}
