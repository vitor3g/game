

export class Game {
  constructor() {}

  public async init() {
    g_core.getTickManager().subscribe("game-loop", this.onClientRender.bind(this))


    return 1;
  }



  public onClientRender() {
    const io = g_core.getGraphics().getGUI().getIO();
    if (!io) return;

    const fps = io.Framerate.toFixed(1);

    const values = {
      fps: fps,
      modelsCount: g_core.getModels().getModelCount(),
      inMemoryObjects: g_core.getObjects().getObjectCount(),
    };


    g_core
      .getGraphics()
      .getGUI()
      .getPrimitiveList()
      .addText(JSON.stringify(values, null, 2), 10, 10, "#090909");
  }
}



export function convertFromIPLtoThreeJS(x: number, y: number, z: number) {
  return {
    x: x,
    y: z,
    z: -y,
  };
}
