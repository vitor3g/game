import { BaseWorld } from "../ecs/BaseWorld";

export class World extends BaseWorld {}